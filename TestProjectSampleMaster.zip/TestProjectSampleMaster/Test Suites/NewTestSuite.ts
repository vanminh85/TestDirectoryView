<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>NewTestSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>6a167ed7-3d57-4dda-a873-3cf3d1984c0f</testSuiteGuid>
   <testCaseLink>
      <guid>2051f035-07a7-4b76-b617-3e5da903f5b7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Folder.Test.Case/Folder1.Folder2.Folder3/Form1234</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
